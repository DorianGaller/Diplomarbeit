using UnityEngine;
using System.Collections;

public class EnemyShoot : MonoBehaviour
{
    public Transform player;
    public GameObject gunshotPrefab;
    public Transform shootPoint;

    public float shootRange = 10f;
    public float shootInterval = 2f;
    private float shootTimer;

    private EnemyAnimator enemyAnimator;
    private EnemyFollow enemyFollow;   // NEU

    void Start()
    {
        if (player == null)
            player = GameObject.FindGameObjectWithTag("Player").transform;

        enemyAnimator = GetComponent<EnemyAnimator>();
        enemyFollow = GetComponent<EnemyFollow>();   // NEU
    }

    void Update()
    {
        shootTimer += Time.deltaTime;

        if (shootTimer >= shootInterval)
        {
            if (Vector2.Distance(transform.position, player.position) <= shootRange)
            {
                Shoot();
                shootTimer = 0f;
            }
        }
    }

    private void Shoot()
    {
        if (!player || !gunshotPrefab || !shootPoint) return;

        if (enemyAnimator != null)
        {
            enemyAnimator.TriggerShoot();
            StartCoroutine(ShootSequence(enemyAnimator.GetShootAnimationDuration()));
        }
        else
        {
            FireBullet();   // Fallback ohne Animator: sofort schießen
        }
    }

    IEnumerator ShootSequence(float delay)   // NEU
    {
        if (enemyFollow != null)
            enemyFollow.enabled = false;

        yield return new WaitForSeconds(delay);

        FireBullet();

        if (enemyFollow != null)
            enemyFollow.enabled = true;
    }

    void FireBullet()
    {
        if (!player || !gunshotPrefab || !shootPoint) return;

        Vector2 shootDir = (player.position - shootPoint.position).normalized;

        GameObject shot = Instantiate(
            gunshotPrefab,
            shootPoint.position,
            Quaternion.identity
        );

        shot.GetComponent<GunshotEffect>()?.Init(shootDir);
    }
}