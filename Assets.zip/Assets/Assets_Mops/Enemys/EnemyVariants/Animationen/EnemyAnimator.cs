using UnityEngine;
using System.Collections;

[RequireComponent(typeof(Animator))]
public class EnemyAnimator : MonoBehaviour
{
    [SerializeField] private EnemyFollow follow;
    [SerializeField] private SpriteRenderer spriteRenderer;

    [Header("Anti-Flicker")]
    [Tooltip("Wie lange der gegenteilige Zustand anhalten muss, bevor wirklich umgeschaltet wird")]
    [SerializeField] private float stateChangeDelay = 0.1f;

    [Header("Shoot Animation")]
    [Tooltip("Name des Shoot-Animation-Clips, wird beim Start automatisch aus dem Controller gelesen")]
    [SerializeField] private string shootClipName = "Robot_Shooting";
    private float shootAnimationDuration = 0.5f;   // Fallback, falls Clip nicht gefunden wird

    private Animator animator;
    private Transform player;

    private bool currentIsMoving = false;
    private float stateTimer = 0f;

    void Awake()
    {
        animator = GetComponent<Animator>();

        if (follow == null) follow = GetComponent<EnemyFollow>();
        if (spriteRenderer == null) spriteRenderer = GetComponent<SpriteRenderer>();
    }

    void Start()
    {
        GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
        if (playerObj != null)
            player = playerObj.transform;

        CacheShootAnimationDuration();
    }

    void CacheShootAnimationDuration()
    {
        if (animator == null || animator.runtimeAnimatorController == null) return;

        foreach (AnimationClip clip in animator.runtimeAnimatorController.animationClips)
        {
            if (clip.name == shootClipName)
            {
                shootAnimationDuration = clip.length;
                break;
            }
        }
    }

    void Update()
    {
        bool rawIsMoving = false;
        if (player != null && follow != null)
        {
            float distance = Vector2.Distance(transform.position, player.position);
            float stopDistance = follow.shootRange - follow.stopOffset;
            rawIsMoving = distance > stopDistance;
        }

        if (rawIsMoving != currentIsMoving)
        {
            stateTimer += Time.deltaTime;
            if (stateTimer >= stateChangeDelay)
            {
                currentIsMoving = rawIsMoving;
                stateTimer = 0f;
                animator.SetBool("IsMoving", currentIsMoving);
            }
        }
        else
        {
            stateTimer = 0f;
        }

        if (player != null && spriteRenderer != null)
        {
            Vector3 scale = transform.localScale;
            float dirX = player.position.x - transform.position.x;
            if (Mathf.Abs(dirX) > 0.05f)
                scale.x = Mathf.Abs(scale.x) * (dirX < 0 ? -1 : 1);
            transform.localScale = scale;
        }
    }

    public float GetShootAnimationDuration() => shootAnimationDuration;

    public void TriggerShoot()
    {
        if (animator == null) return;

        animator.SetTrigger("Shoot");
        animator.SetBool("IsShooting", true);

        StopCoroutine(nameof(ClearShootingFlagAfterDelay));
        StartCoroutine(ClearShootingFlagAfterDelay());
    }

    IEnumerator ClearShootingFlagAfterDelay()
    {
        yield return new WaitForSeconds(shootAnimationDuration);
        animator.SetBool("IsShooting", false);
    }
}